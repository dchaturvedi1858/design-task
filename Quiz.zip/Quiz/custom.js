var ques = document.getElementById('quiz-content');

function index() {
    const xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            const data = JSON.parse(this.responseText).data;
   // let list = [];
    var flat = [];
    var flat1 = [];
            for (i = 0; i < data.length; i++) {
                var headings = `${data[i].question}`

                flat = flat.concat(headings);
     
                    Object.keys(data.id).forEach(arrName => {
                $(Layer1).append(`<option>${arrName}</option>`);
              });


               var results = Object.keys(flat).map(e => ({flat: e, count: flat[e]}))
              // console.log(headings);
                var option = data[i].options;
                for (j = 0; j < option.length; j++) {
                   // var flat2 = [];
                  var headings1 = `${option[j]}`
                // flat = flat2.concat(headings1);
                //  var results1 = Object.keys(flat1).map(e => ({flat1: e, count: flat1[e]}))     
                }
               
             }
             
            console.log(results);
          
           const data1 = {
             "Array1":["A","B","C","D"] ,
              "Array2":["W","X","Y","Z"]
            };

            // Object.keys(data1).forEach(arrName => {
            //   $(Layer1).append(`<option>${arrName}</option>`);
            // });
            
            // $(Layer1).on('change', function() {
            //   const arrName = $(this).val();
            //   if (arrName) {
            //     $('.dynamic').remove();
            //     data1[arrName].forEach(value => {
            //       $(Layer2).append(`<option class="dynamic">${value}</option>`);
            //     });
            //     $(Layer2).show();
            //   } else {
            //     $(Layer2).hide();
            //   }
            // });



 //document.getElementById("quiz-content").innerHTML = flat.map(({flat}) => `${flat}`).join("<br/>");
 //document.getElementById("quiz-contents").innerHTML = lists.map(({question}) => `${question}`).join("<br/>");
     //  document.getElementById("quiz-content").innerHTML += `<br> ${results}` ;
      //   document.getElementById("quiz-content").innerHTML += `<br> ${flat1} ` ;
        }
    };
    xhttp.open("GET", "ques.json", true);
    xhttp.send();
}



index();





